#!/usr/bin/env bash

pyuic5 ui/mainwindow.ui -o ui/mainwindow.py
